#version 400 compatibility
#define WORLD_NETHER
#define PROGRAM_GBUFFERS_ENTITIES_TRANSLUCENT
#define vsh
#include "/program/gbuffer/translucent.glsl"
