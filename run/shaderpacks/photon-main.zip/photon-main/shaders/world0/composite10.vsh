#version 400 compatibility
#define WORLD_OVERWORLD
#define BLOOM_TILE_INDEX 5
#define vsh
#include "/program/post/bloom/downsample.glsl"
